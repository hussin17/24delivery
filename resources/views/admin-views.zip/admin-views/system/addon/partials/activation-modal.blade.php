<div class="modal fade" id="activatedThemeModal" tabindex="-1" role="dialog" aria-labelledby="activatedThemeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="activateData">

        </div>
    </div>
</div>
