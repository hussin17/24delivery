
<input type="hidden" value="{{ $template }}" name="email_template">
