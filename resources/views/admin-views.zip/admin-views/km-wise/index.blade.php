@extends('layouts.admin.app')

@section('title', translate('Item List'))

@push('css_or_js')
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endpush

@section('content')
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center g-2">
                <div class="col-md-9 col-12">
                    <h1 class="page-header-title">
                        <span class="page-header-icon">
                            <img src="{{ asset('public/assets/admin/img/items.png') }}" class="w--22" alt="">
                        </span>
                        <span>
                            {{ translate('messages.cities_list') }} <span class="badge badge-soft-dark ml-2"
                                id="foodCount">{{ $kmWise->total() }}</span>
                        </span>
                    </h1>
                </div>
            </div>

        </div>
        <!-- End Page Header -->
        <!-- Card -->

        @php
            $pharmacy = 0;
            if (Config::get('module.current_module_type') == 'pharmacy') {
                $pharmacy = 1;
            }
        @endphp
        <div class="card mb-3">
            <!-- Header -->
            <div class="card-header py-2 border-0">
                <h1>{{ translate('search_data') }}</h1>
            </div>
            <div class="row mr-1 ml-2 mb-5">
                <div class="col-sm-6 col-md-3">
                    @if (!isset(auth('admin')->user()->zone_id))
                        <div class="select-item">
                            <select name="zone_id" class="form-control js-select2-custom set-filter"
                                data-url="{{ url()->full() }}" data-filter="zone_id">
                                <option value="" {{ !request('zone_id') ? 'selected' : '' }}>
                                    {{ translate('messages.All_Zones') }}</option>
                                @foreach (\App\Models\Zone::orderBy('name')->get(['id', 'name']) as $z)
                                    <option value="{{ $z['id'] }}"
                                        {{ request()?->zone_id == $z['id'] ? 'selected' : '' }}>
                                        {{ $z['name'] }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    @endif
                </div>
            </div>

        </div>

        <div class="card">
            <!-- Header -->
            <div class="card-header py-2 border-0">
                <div class="search--button-wrapper justify-content-end">
                    {{-- <form class="search-form">
                        {{-- @csrf
                        <!-- Search
                        <div class="input-group input--group">
                            <input id="datatableSearch" name="search" value="{{ request()?->search ?? null }}"
                                type="search" class="form-control h--40px"
                                placeholder="{{ translate('ex_:_search_item_by_name') }}"
                                aria-label="{{ translate('messages.search_here') }}">
                            <button type="submit" class="btn btn--secondary h--40px"><i class="tio-search"></i></button>
                        </div>
                         End Search
                    </form> --}}
                    <div class="d-flex flex-wrap flex-row p-2 add--city-btn">
                        <button class="btn btn--primary" data-toggle="modal"
                            data-target="#add-km">{{ translate('messages.add_new_km') }}</button>
                    </div>
                </div>
                <!-- End Row -->
            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive datatable-custom" id="table-div">
                <table id="datatable"
                    class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                    data-hs-datatables-options='{
                        "columnDefs": [{
                            "targets": [],
                            "width": "5%",
                            "orderable": false
                        }],
                        "order": [],
                        "info": {
                        "totalQty": "#datatableWithPaginationInfoTotalQty"
                        },

                        "entries": "#datatableEntries",

                        "isResponsive": false,
                        "isShowPaging": false,
                        "paging":false
                    }'>
                    <thead class="thead-light">
                        <tr>
                            <th class="border-0">{{ translate('sl') }}</th>
                            <th class="border-0">{{ translate('messages.from-to') }}</th>
                            <th class="border-0 text-center">{{ translate('messages.price') }}</th>
                            <th class="border-0">{{ translate('messages.store') }}</th>
                            {{-- <th class="border-0 text-center">{{ translate('messages.status') }}</th> --}}
                            <th class="border-0 text-center">{{ translate('messages.action') }}</th>
                        </tr>
                    </thead>

                    <tbody id="set-rows">
                        @foreach ($kmWise as $key => $item)
                            <tr>
                                <td>{{ $key + $kmWise->firstItem() }}</td>
                                <td>
                                    {{ Str::limit($item->from) }} - {{ Str::limit($item->to) }}
                                </td>
                                <td>
                                    <div class="text-right mw--85px">
                                        {{ \App\CentralLogics\Helpers::format_currency($item['price']) }}
                                    </div>
                                </td>
                                <td>
                                    @if ($item->store)
                                        <a href="{{ route('admin.store.view', $item->store->id) }}" class="table-rest-info"
                                            alt="view store">
                                            {{ Str::limit($item->store->name, 20, '...') }}</a>
                                    @else
                                        {{ translate('messages.store deleted!') }}
                                    @endif

                                </td>
                                <td>
                                    <div class="btn--container justify-content-center">
                                        <a class="btn action-btn btn--primary btn-outline-primary" href="javascript:"
                                            data-toggle="modal" data-target="#edit-km-{{ $item['id'] }}"
                                            data-message="{{ translate('messages.Want_to_edit_this_item') }}"
                                            title="{{ translate('messages.edit_item') }}"><i class="tio-edit"></i>
                                        </a>
                                        <div class="modal fade" id="edit-km-{{ $item['id'] }}" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">{{ translate('add_new_km') }}</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form
                                                            action="{{ route('admin.business-settings.km_wise.update', $item->id) }}"
                                                            method="post" id="product_form">
                                                            @csrf
                                                            @method('PUT')
                                                            <div class="row">
                                                                <div class="col-12 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="store_id"
                                                                            class="input-label">{{ translate('select_store') }}
                                                                            <span
                                                                                class="input-label-secondary text-danger">*</span></label>
                                                                        <select id="store_id" name="store_id"
                                                                            class="form-control"
                                                                            placeholder="{{ translate('store_name') }}"
                                                                            required>
                                                                            <option value="">
                                                                                {{ translate('messages.please_select_store') }}
                                                                            </option>
                                                                            @foreach ($stores as $store)
                                                                                <option value="{{ $store->id }}">
                                                                                    {{ $store->name }}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-12 col-lg-6 d-flex g-2">
                                                                    <div class="form-group">
                                                                        <label for="from"
                                                                            class="input-label">{{ translate('from') }}
                                                                            <span
                                                                                class="input-label-secondary text-danger">*</span>
                                                                        </label>
                                                                        <input id="from" type="number" name="from"
                                                                            min="1" class="form-control"
                                                                            value="{{ $item->from }}"
                                                                            placeholder="{{ translate('messages.from') }}"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="to"
                                                                            class="input-label">{{ translate('to') }}
                                                                            <span
                                                                                class="input-label-secondary text-danger">*</span></label>
                                                                        <input id="to" type="number"
                                                                            name="to" class="form-control"
                                                                            value="{{ $item->to }}"
                                                                            placeholder="{{ translate('messages.to') }}"
                                                                            required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-12 col-lg-6">
                                                                    <div class="form-group">
                                                                        <label for="charge_value"
                                                                            class="input-label">{{ translate('charge value') }}<span
                                                                                class="input-label-secondary text-danger">*</span></label>
                                                                        <input id="charge_value" type="number"
                                                                            name="charge_value" class="form-control"
                                                                            value="{{ $item->price }}"
                                                                            placeholder="{{ translate('messages.charge value') }}"
                                                                            required>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="btn--container justify-content-end">
                                                                <button type="reset"
                                                                    class="btn btn--reset">{{ translate('reset') }}</button>
                                                                <button type="submit" id="submit_new_km"
                                                                    class="btn btn--primary">{{ translate('submit') }}</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <a class="btn  action-btn btn--danger btn-outline-danger form-alert"
                                            href="javascript:" data-id="food-{{ $item['id'] }}"
                                            data-message="{{ translate('messages.Want_to_delete_this_item') }}"
                                            title="{{ translate('messages.delete_item') }}">
                                            <i class="tio-delete-outlined"></i>
                                        </a>
                                        <form
                                            action="{{ route('admin.business-settings.km_wise.destroy', [$item['id']]) }}"
                                            method="post" id="food-{{ $item['id'] }}">
                                            @csrf @method('delete')
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @if (count($kmWise) !== 0)
                    <hr>
                @endif
                <div class="page-area">
                    <tfoot class="border-top">
                        {!! $kmWise->withQueryString()->links() !!}
                </div>
                @if (count($kmWise) === 0)
                    <div class="empty--data">
                        <img src="{{ asset('/public/assets/admin/svg/illustrations/sorry.svg') }}" alt="public">
                        <h5>
                            {{ translate('no_data_found') }}
                        </h5>
                    </div>
                @endif
            </div>
            <!-- End Table -->
        </div>
        <!-- End Card -->
    </div>

    <div class="modal fade" id="add-km" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ translate('add_new_km') }}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('admin.business-settings.km_wise.store') }}" method="post"
                        id="product_form">
                        @csrf
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="form-group">
                                    <label for="store_id" class="input-label">{{ translate('select_store') }}
                                        <span class="input-label-secondary text-danger">*</span></label>
                                    <select id="store_id" type="text" name="store_id" class="form-control"
                                        value="{{ old('store_id') }}" placeholder="{{ translate('store_name') }}"
                                        required>
                                        <option value="">{{ translate('messages.please_select_store') }}</option>
                                        @foreach ($stores as $store)
                                            <option value="{{ $store->id }}">{{ $store->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6 d-flex g-2">
                                <div class="form-group">
                                    <label for="from" class="input-label">{{ translate('from') }} <span
                                            class="input-label-secondary text-danger">*</span></label>
                                    <input id="from" type="number" name="from" min="1"
                                        class="form-control" value="{{ old('from') }}"
                                        placeholder="{{ translate('messages.from') }}" required>
                                </div>
                                <div class="form-group">
                                    <label for="to" class="input-label">{{ translate('to') }} <span
                                            class="input-label-secondary text-danger">*</span></label>
                                    <input id="to" type="number" name="to" class="form-control"
                                        value="{{ old('to') }}" placeholder="{{ translate('messages.to') }}"
                                        required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="form-group">
                                    <label for="charge_value" class="input-label">{{ translate('charge value') }}<span
                                            class="input-label-secondary text-danger">*</span></label>
                                    <input id="charge_value" type="number" name="charge_value" class="form-control"
                                        value="{{ old('charge_value') }}"
                                        placeholder="{{ translate('messages.charge value') }}" required>
                                </div>
                            </div>
                        </div>
                        <div class="btn--container justify-content-end">
                            <button type="reset" class="btn btn--reset">{{ translate('reset') }}</button>
                            <button type="submit" id="submit_new_km"
                                class="btn btn--primary">{{ translate('submit') }}</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('script_2')
    <script>
        "use strict";
        $(document).on('ready', function() {
            // INITIALIZATION OF DATATABLES
            // =======================================================
            let datatable = $.HSCore.components.HSDatatables.init($('#datatable'), {
                select: {
                    style: 'multi',
                    classMap: {
                        checkAll: '#datatableCheckAll',
                        counter: '#datatableCounter',
                        counterInfo: '#datatableCounterInfo'
                    }
                },
                language: {
                    zeroRecords: '<div class="text-center p-4">' +
                        '<img class="w-7rem mb-3" src="{{ asset('public/assets/admin/svg/illustrations/sorry.svg') }}" alt="Image Description">' +

                        '</div>'
                }
            });

            $('#datatableSearch').on('mouseup', function(e) {
                let $input = $(this),
                    oldValue = $input.val();

                if (oldValue == "") return;

                setTimeout(function() {
                    let newValue = $input.val();

                    if (newValue == "") {
                        // Gotcha
                        datatable.search('').draw();
                    }
                }, 1);
            });

            $('#toggleColumn_index').change(function(e) {
                datatable.columns(0).visible(e.target.checked)
            })
            $('#toggleColumn_name').change(function(e) {
                datatable.columns(1).visible(e.target.checked)
            })

            $('#toggleColumn_type').change(function(e) {
                datatable.columns(2).visible(e.target.checked)
            })

            $('#toggleColumn_vendor').change(function(e) {
                datatable.columns(3).visible(e.target.checked)
            })

            $('#toggleColumn_status').change(function(e) {
                datatable.columns(5).visible(e.target.checked)
            })
            $('#toggleColumn_price').change(function(e) {
                datatable.columns(4).visible(e.target.checked)
            })
            $('#toggleColumn_action').change(function(e) {
                datatable.columns(6).visible(e.target.checked)
            })

            // INITIALIZATION OF SELECT2
            // =======================================================
            $('.js-select2-custom').each(function() {
                let select2 = $.HSCore.components.HSSelect2.init($(this));
            });
        });

        $('#condition_id').select2({
            ajax: {
                url: '{{ url('/') }}/admin/common-condition/get-all',
                data: function(params) {
                    return {
                        q: params.term, // search term
                        page: params.page,
                        all: true,
                    };
                },
                processResults: function(data) {
                    return {
                        results: data
                    };
                },
                __port: function(params, success, failure) {
                    let $request = $.ajax(params);

                    $request.then(success);
                    $request.fail(failure);

                    return $request;
                }
            }
        });
    </script>
@endpush
