<?php

const POINT_SRID = 0; // For MariaDB use 4326