<?php

namespace App\Enums\ExportFileNames\Admin;

enum Coupon
{
    const EXPORT_CSV = 'Coupons.csv';
    const EXPORT_XLSX = 'Coupons.xlsx';
}
