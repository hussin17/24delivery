<?php

namespace App\Enums\ExportFileNames\Admin;

enum Notification
{
    const EXPORT_CSV = 'Notification.csv';
    const EXPORT_XLSX = 'Notification.xlsx';
}
