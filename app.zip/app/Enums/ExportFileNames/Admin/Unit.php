<?php

namespace App\Enums\ExportFileNames\Admin;

enum Unit
{
    const EXPORT_CSV = 'Units.csv';
    const EXPORT_XLSX = 'Units.xlsx';
}
